import axios from 'axios';
import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import './Form.css';

const Form = () => {
  const [query, setQuery] = useState('');
  const [searchedMovieList, setSearchedMovieList] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(undefined);
  const [movie, setMovie] = useState(undefined);
  const [title, setTitle] = useState('');
  const [overview, setOverview] = useState('');
  const [popularity, setPopularity] = useState('');
  const [releaseDate, setReleaseDate] = useState('');
  const [voteAverage, setVoteAverage] = useState('');
  let { movieId } = useParams();

  const handleSearch = useCallback(() => {
    axios
      .get(
        `https://api.themoviedb.org/3/search/movie?query=${query}&include_adult=false&language=en-US&page=1`,
        {
          headers: {
            Accept: 'application/json',
            Authorization:
              'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5YTdiNmUyNGJkNWRkNjhiNmE1ZWFjZjgyNWY3NGY5ZCIsIm5iZiI6MTcyOTI5NzI5Ny4wNzMzNTEsInN1YiI6IjY2MzhlZGM0MmZhZjRkMDEzMGM2NzM3NyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.ZIX4EF2yAKl6NwhcmhZucxSQi1rJDZiGG80tDd6_9XI',
          },
        }
      )
      .then((response) => {
        setSearchedMovieList(response.data.results);
      })
      .catch((error) => console.error('Error fetching movies:', error));
  }, [query]);

  const handleSelectMovie = (movie) => {
    setSelectedMovie(movie);
    setTitle(movie.original_title);
    setOverview(movie.overview);
    setPopularity(movie.popularity);
    setReleaseDate(movie.release_date);
    setVoteAverage(movie.vote_average);
  };

  const handleSave = () => {
    const accessToken = localStorage.getItem('accessToken');
    if (!selectedMovie) {
      alert('Please search and select a movie.');
      return;
    }

    const data = {
      tmdbId: selectedMovie.id,
      title: title,
      overview: overview,
      popularity: parseFloat(popularity), 
      releaseDate: releaseDate,
      voteAverage: parseFloat(voteAverage), 
      backdropPath: `https://image.tmdb.org/t/p/original/${selectedMovie.backdrop_path}`,
      posterPath: `https://image.tmdb.org/t/p/original/${selectedMovie.poster_path}`,
      isFeatured: 0,
    };

    const method = movieId ? 'put' : 'post';
    const url = movieId ? `/movies/${movieId}` : '/movies';

    axios({
      method,
      url,
      data,
      headers: {
        Authorization: `Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5YTdiNmUyNGJkNWRkNjhiNmE1ZWFjZjgyNWY3NGY5ZCIsIm5iZiI6MTcyOTI5NzI5Ny4wNzMzNTEsInN1YiI6IjY2MzhlZGM0MmZhZjRkMDEzMGM2NzM3NyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.ZIX4EF2yAKl6NwhcmhZucxSQi1rJDZiGG80tDd6_9XI'`,
      },
    })
      .then((response) => {
        alert(`Movie ${movieId ? 'updated' : 'saved'} successfully!`);
        console.log(response);
      })
      .catch((error) => {
        console.error('Error saving/updating movie:', error);
        alert('An error occurred while saving/updating the movie.');
      });
  };

  useEffect(() => {
    if (movieId) {
      axios
        .get(`/movies/${movieId}`)
        .then((response) => {
          setMovie(response.data);
          const tempData = {
            id: response.data.tmdbId,
            original_title: response.data.title,
            overview: response.data.overview,
            popularity: response.data.popularity,
            poster_path: response.data.posterPath,
            release_date: response.data.releaseDate,
            vote_average: response.data.voteAverage,
          };
          setSelectedMovie(tempData);
          setTitle(response.data.title);
          setOverview(response.data.overview);
          setPopularity(response.data.popularity);
          setReleaseDate(response.data.releaseDate);
          setVoteAverage(response.data.voteAverage);
        })
        .catch((error) => console.error('Error fetching movie details:', error));
    }
  }, [movieId]);

  return (
    <>
      <h1>{movieId ? 'Edit ' : 'Create '} Movie</h1>

      {!movieId && (
        <>
          <div className="search-container">
            <label>
              Search Movie:
              <input
                type="text"
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Enter movie name"
              />
            </label>
            <button type="button" onClick={handleSearch}>
              Search
            </button>
            <div className="searched-movie">
              {searchedMovieList.map((movie) => (
                <p
                  key={movie.id}
                  onClick={() => handleSelectMovie(movie)}
                  style={{ cursor: 'pointer' }}
                >
                  {movie.original_title}
                </p>
              ))}
            </div>
          </div>
          <hr />
        </>
      )}

      <div className="container">
        <form>
          {selectedMovie ? (
            <img
              className="poster-image"
              src={`https://image.tmdb.org/t/p/original/${selectedMovie.poster_path}`}
              alt="Selected movie poster"
            />
          ) : (
            ''
          )}
          <div className="field">
            <label>
              Title:
              <input
                type="text"
                value={title}
                onChange={(event) => setTitle(event.target.value)}
              />
            </label>
          </div>
          <div className="field">
            <label>
              Overview:
              <textarea
                rows={5}
                value={overview}
                onChange={(event) => setOverview(event.target.value)}
              />
            </label>
          </div>
          <div className="field">
            <label>
              Popularity:
              <input
                type="text"
                value={popularity}
                onChange={(event) => setPopularity(event.target.value)}
              />
            </label>
          </div>
          <div className="field">
            <label>
              Release Date:
              <input
                type="text"
                value={releaseDate}
                onChange={(event) => setReleaseDate(event.target.value)}
              />
            </label>
          </div>
          <div className="field">
            <label>
              Vote Average:
              <input
                type="text"
                value={voteAverage}
                onChange={(event) => setVoteAverage(event.target.value)}
              />
            </label>
          </div>
          <button type="button" onClick={handleSave}>
            Save
          </button>
        </form>
      </div>
    </>
  );
};

export default Form;
